![INVENTORY MANAGEMENT SYSTEM (1)](https://user-images.githubusercontent.com/89722457/192203902-875217f5-3944-47a9-b761-7b2b1a96b1ac.png)

> ASSIGNMENT DETAILS


| NAME | ASSIGNMENT-1 | ASSIGNMENT-2 | ASSIGNMENT-3 | ASSIGNMENT-4 |
|     :---:    |     :---:      |     :---:     |     :---:    |     :---:      |
| ATHIVIGNESHKUMAR N   | [Assignment-1](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/ATHIVIGNESHKUMAR%20N/Assignment-1)    | [Assignment-2](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/ATHIVIGNESHKUMAR%20N/ASSIGNMENT-2)    | [Assignment-3](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/ATHIVIGNESHKUMAR%20N/ASSIGNMENT-3)   | Assignment-4     |
| CHANDHRU R     | [Assignment-1](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/CHANDHRU%20R/assignment)       | [Assignment-2](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/CHANDHRU%20R/Assignment-2)      | [Assignment-3](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/CHANDHRU%20R/Assignment-3)     | Assignment-4       |
| LOKESH IYYAPPAN A     | [Assignment-1](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/LOKESH%20IYYAPPAN%20A/assignment-1)       | [Assignment-2](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/LOKESH%20IYYAPPAN%20A/Assignment-2)      | [Assignment-3](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/LOKESH%20IYYAPPAN%20A/Assignment-3)     | Assignment-4       |
| PRASATH A     | [Assignment-1](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/PRASATH%20A/Assignment-1)       | [Assignment-2](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/PRASATH%20A/Assignment_2)      | [Assignment-3](https://github.com/IBM-EPBL/IBM-Project-54059-1661588263/tree/master/Assignments/PRASATH%20A/assignment_3)     | Assignment-4      |

